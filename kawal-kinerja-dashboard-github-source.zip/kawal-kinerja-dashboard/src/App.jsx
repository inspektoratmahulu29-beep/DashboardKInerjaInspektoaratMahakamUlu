import { useEffect, useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Activity, AlertTriangle, BarChart3, BookOpen, Boxes, ChevronRight, CircleGauge, ClipboardCheck,
  Database, FileSpreadsheet, Gauge, Layers3, LayoutDashboard, Menu, RefreshCcw, Search, ShieldCheck,
  Sparkles, Target, TrendingUp, Upload, WalletCards, X, Zap
} from 'lucide-react'
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Line, Pie, PieChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis
} from 'recharts'
import { loadWorkbook, SHEETS, WORKBOOK_URL, formatCompactCurrency, formatCurrency } from './dataModel'

const nav = [
  ['dashboard', 'Dashboard', LayoutDashboard],
  ['performance', 'Kinerja', Target],
  ['monev', 'Monev', Activity],
  ['pkpt', 'PKPT', ClipboardCheck],
  ['budget', 'Anggaran', WalletCards],
  ['workpaper', 'Kertas Kerja', FileSpreadsheet],
  ['quality', 'Data Quality', ShieldCheck]
]

const tone = {
  blue: 'var(--blue)',
  violet: 'var(--violet)',
  mint: 'var(--mint)',
  amber: 'var(--amber)',
  rose: 'var(--rose)'
}

function pct(n) { return n == null || !Number.isFinite(n) ? '—' : `${n.toFixed(1)}%` }
function num(n) { return n == null || !Number.isFinite(n) ? '—' : new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 }).format(n) }
function safeArr(v) { return Array.isArray(v) ? v : [] }

function AnimatedBackground() {
  return <div className="ambient" aria-hidden="true">
    <motion.div className="orb orb-1" animate={{ x: [0, 35, -10, 0], y: [0, -20, 18, 0], scale: [1, 1.08, .98, 1] }} transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }} />
    <motion.div className="orb orb-2" animate={{ x: [0, -28, 15, 0], y: [0, 28, -12, 0], scale: [1, .95, 1.1, 1] }} transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }} />
    <motion.div className="orb orb-3" animate={{ x: [0, 22, -30, 0], y: [0, 10, -24, 0] }} transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }} />
  </div>
}

function Pill({ children, kind='muted' }) { return <span className={`pill pill-${kind}`}>{children}</span> }

function MetricCard({ icon: Icon, label, value, sub, accent='blue', progress, onClick }) {
  return <motion.button className={`metric-card accent-${accent}`} whileHover={{ y: -4, scale: 1.01 }} whileTap={{ scale: .995 }} onClick={onClick}>
    <div className="metric-top"><span className="iconbox"><Icon size={18}/></span><span className="metric-label">{label}</span><ChevronRight size={17} className="chev"/></div>
    <div className="metric-value">{value}</div>
    {progress != null && <div className="metric-progress"><span style={{ width: `${Math.max(0, Math.min(progress, 100))}%` }} /></div>}
    <div className="metric-sub">{sub}</div>
  </motion.button>
}

function SectionHeader({ eyebrow, title, right }) {
  return <div className="section-head">
    <div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div>
    {right}
  </div>
}

function ChartCard({ title, subtitle, children, className='' }) {
  return <section className={`panel chart-card ${className}`}>
    <div className="panel-head"><div><h3>{title}</h3>{subtitle && <span>{subtitle}</span>}</div></div>
    <div className="chart-wrap">{children}</div>
  </section>
}

function EmptyState({ title='Belum ada data', body='Isi data pada kertas kerja lalu refresh dashboard.' }) {
  return <div className="empty"><div className="empty-icon"><Database size={22}/></div><strong>{title}</strong><span>{body}</span></div>
}

function Dashboard({ model, go }) {
  const statusData = [
    { name: 'Sudah', value: model.pkpt.status.Sudah },
    { name: 'Berjalan', value: model.pkpt.status['Sedang Berjalan'] },
    { name: 'Belum', value: model.pkpt.status.Belum },
  ]
  const qData = model.monevProgram.quarterlyOutputs.map((v, i) => ({ name: `TW ${i + 1}`, value: v }))
  const irbanData = Object.entries(model.pkpt.byIrban).map(([name, x]) => ({ name: name.replace('Irban ', 'IRBAN '), value: x.sudah / Math.max(x.total, 1) * 100 }))
  const spend = model.monevProgram.budget ? model.monevProgram.realization / model.monevProgram.budget * 100 : null
  return <div className="page">
    <SectionHeader eyebrow="Performance control room" title="Database Realisasi Kinerja" right={<div className="hero-meta"><Pill kind="year">TA {model.meta.year}</Pill><Pill kind={model.meta.formulaErrors ? 'warn' : 'ok'}>{model.meta.formulaErrors ? `${model.meta.formulaErrors} formula bermasalah` : 'Data sehat'}</Pill></div>} />
    <section className="hero-grid">
      <div className="hero panel">
        <div className="hero-copy"><span className="spark"><Sparkles size={14}/> LIVE KERTAS KERJA</span><h1>Kontrol kinerja<br/><em>berbasis data</em>.</h1><p>Seluruh KPI dirakit langsung dari sheet workbook sehingga dashboard mengikuti perubahan database, bukan angka yang dipaint manual.</p><div className="hero-actions"><button className="primary-btn" onClick={() => go('workpaper')}><BookOpen size={16}/> Buka kertas kerja</button><button className="ghost-btn" onClick={() => go('quality')}><ShieldCheck size={16}/> Cek data</button></div></div>
        <div className="hero-radar"><div className="radar-ring r1"/><div className="radar-ring r2"/><div className="radar-ring r3"/><div className="radar-core"><Gauge size={25}/><strong>{pct(spend)}</strong><span>Realisasi anggaran</span></div></div>
      </div>
      <div className="panel snapshot">
        <div className="panel-head"><div><h3>Snapshot hari ini</h3><span>Ringkasan lintas sheet</span></div><Zap size={17}/></div>
        <div className="snap-list">
          <div><span>PKPT selesai</span><strong>{pct(model.pkpt.completion)}</strong><small>{model.pkpt.status.Sudah} dari {model.pkpt.total} penugasan</small></div>
          <div><span>PKPT progres</span><strong>{pct(model.pkpt.progress)}</strong><small>Sudah + sedang berjalan</small></div>
          <div><span>Realisasi keuangan</span><strong>{formatCompactCurrency(model.monevProgram.realization)}</strong><small>dari {formatCompactCurrency(model.monevProgram.budget)}</small></div>
        </div>
      </div>
    </section>

    <div className="metric-grid">
      <MetricCard icon={Target} label="Indikator IKU" value={num(model.iku.count)} sub="Sheet IKU • indikator terisi" accent="violet" onClick={() => go('performance')}/>
      <MetricCard icon={Layers3} label="Rencana aksi" value={num(model.rencana.count)} sub="Indikator / sasaran yang termonitor" accent="blue" onClick={() => go('performance')}/>
      <MetricCard icon={ClipboardCheck} label="Penugasan PKPT" value={num(model.pkpt.total)} sub={`${model.pkpt.status.Sudah} selesai • ${model.pkpt.status.Belum} belum`} accent="mint" onClick={() => go('pkpt')} progress={model.pkpt.completion}/>
      <MetricCard icon={TrendingUp} label="Progres PKPT" value={pct(model.pkpt.progress)} sub="Sudah + sedang berjalan" accent="amber" onClick={() => go('pkpt')} progress={model.pkpt.progress}/>
      <MetricCard icon={WalletCards} label="Pagu monev program" value={formatCompactCurrency(model.monevProgram.budget)} sub={`Realisasi ${pct(spend)}`} accent="blue" onClick={() => go('budget')} progress={spend}/>
      <MetricCard icon={Boxes} label="Output penugasan" value={num(model.pkpt.outputRealized)} sub="Realisasi output yang terbaca" accent="rose" onClick={() => go('pkpt')}/>
    </div>

    <div className="two-col">
      <ChartCard title="Status PKPT" subtitle="Distribusi realisasi pada Rekap realisasi PKPT">
        <ResponsiveContainer width="100%" height={260}><PieChart><Pie data={statusData} innerRadius={70} outerRadius={98} paddingAngle={5} dataKey="value"><Cell fill="#4ade80"/><Cell fill="#fbbf24"/><Cell fill="#fb7185"/></Pie><Tooltip contentStyle={{ background: '#10162a', border: '1px solid rgba(255,255,255,.1)', borderRadius: 14, color: '#fff' }}/></PieChart></ResponsiveContainer>
        <div className="donut-center"><strong>{num(model.pkpt.total)}</strong><span>penugasan</span></div>
        <div className="legend-row">{statusData.map((x, i) => <span key={x.name}><i className={`dot d${i}`}/>{x.name} <b>{x.value}</b></span>)}</div>
      </ChartCard>
      <ChartCard title="Realisasi output per triwulan" subtitle="Monev Program • angka output yang berhasil diparsing">
        {qData.some(x => x.value) ? <ResponsiveContainer width="100%" height={292}><AreaChart data={qData}><defs><linearGradient id="fillArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#7c6cff" stopOpacity=".55"/><stop offset="100%" stopColor="#7c6cff" stopOpacity="0"/></linearGradient></defs><CartesianGrid stroke="rgba(255,255,255,.07)" vertical={false}/><XAxis dataKey="name" tick={{ fill:'#91a0ba', fontSize:12 }}/><YAxis tick={{ fill:'#91a0ba', fontSize:12 }}/><Tooltip contentStyle={{ background:'#10162a', border:'1px solid rgba(255,255,255,.1)', borderRadius:14, color:'#fff' }}/><Area type="monotone" dataKey="value" stroke="#8b80ff" fill="url(#fillArea)" strokeWidth={2.5}/></AreaChart></ResponsiveContainer> : <EmptyState title="Belum ada output triwulan" body="Kolom pencapaian pada sheet Monev Program belum memuat angka yang dapat diparsing."/>}
      </ChartCard>
    </div>

    <section className="panel ranking-panel">
      <SectionHeader eyebrow="Operational pulse" title="Kinerja penyelesaian per Irban" right={<button className="text-btn" onClick={() => go('pkpt')}>Lihat PKPT <ChevronRight size={15}/></button>} />
      <div className="bar-list">{irbanData.map((x, i) => <div className="bar-row" key={x.name}><div className="bar-label"><span>{x.name}</span><b>{x.value.toFixed(1)}%</b></div><div className="bar-track"><motion.span initial={{ width: 0 }} animate={{ width: `${x.value}%` }} transition={{ duration: .9, delay: i * .08 }} style={{ background: `linear-gradient(90deg, ${i===0?'#62e6c5':i===1?'#7c6cff':'#f0c674'}, transparent)` }}/></div></div>)}</div>
    </section>
  </div>
}

function Performance({ model }) {
  const cards = [
    ['Strategis', model.strategic], ['Program', model.program], ['Kegiatan Utama', model.kegiatan], ['Kegiatan Penunjang', model.penunjangKegiatan], ['Subkegiatan Utama', model.subU], ['Subkegiatan Penunjang', model.subP]
  ]
  return <div className="page">
    <SectionHeader eyebrow="Kinerja berjenjang" title="IKU → Sasaran → Program → Subkegiatan" right={<Pill kind="year">TA {model.meta.year}</Pill>} />
    <div className="metric-grid compact">{cards.map(([label, x], i) => <div className="mini-kpi panel" key={label}><div className="mini-icon"><Target size={17}/></div><div><span>{label}</span><strong>{num(x.count)}</strong><small>indikator yang terisi</small></div></div>)}</div>
    <div className="two-col equal">
      <section className="panel table-panel"><div className="panel-head"><div><h3>IKU</h3><span>Sheet sumber untuk indikator utama</span></div><Pill>{num(model.iku.count)} indikator</Pill></div>{model.iku.data.length ? <DataTable columns={['Indikator Kinerja Utama','Definisi Operasional','Rumus Perhitungan']} rows={model.iku.data.map(r => [r[1], r[2], r[3]])}/> : <EmptyState title="Sheet IKU masih kosong" body="Dashboard membaca sheet IKU apa adanya; isi indikator pada workbook agar muncul di sini."/>}</section>
      <section className="panel table-panel"><div className="panel-head"><div><h3>Rencana Aksi</h3><span>Target tahunan + pencapaian TW</span></div><Pill>{num(model.rencana.count)} indikator</Pill></div><DataTable columns={['Tujuan / Sasaran','Indikator','Target','Unit']} rows={model.rencana.data.filter(r => r[3]).slice(0, 12).map(r => [r[1] || r[2], r[3], r[4], r[12]])}/></section>
    </div>
  </div>
}

function Monev({ model }) {
  const data = [
    { name: 'IKU', value: model.monevIku.count },
    { name: 'Program', value: model.monevProgram.programRows.length },
    { name: 'Output Utama', value: model.outputUtama.count },
    { name: 'Output Penunjang', value: model.outputPenunjang.count }
  ]
  return <div className="page">
    <SectionHeader eyebrow="Monitoring & evaluasi" title="Monev lintas level" right={<Pill kind="ok">Terhubung ke workbook</Pill>} />
    <div className="two-col">
      <ChartCard title="Volume kertas kerja per modul" subtitle="Jumlah record bermakna yang terbaca dari masing-masing sheet">
        <ResponsiveContainer width="100%" height={300}><BarChart data={data} layout="vertical" margin={{ left: 15, right: 15 }}><CartesianGrid stroke="rgba(255,255,255,.07)" horizontal={false}/><XAxis type="number" tick={{ fill:'#91a0ba', fontSize:12 }}/><YAxis dataKey="name" type="category" width={100} tick={{ fill:'#dce4f2', fontSize:12 }}/><Tooltip contentStyle={{ background:'#10162a', border:'1px solid rgba(255,255,255,.1)', borderRadius:14, color:'#fff' }}/><Bar dataKey="value" radius={[0, 8, 8, 0]} fill="#62e6c5" /></BarChart></ResponsiveContainer>
      </ChartCard>
      <section className="panel insight-panel"><div className="panel-head"><div><h3>Temuan cepat</h3><span>Aturan sederhana untuk membaca dashboard</span></div><AlertTriangle size={17}/></div><div className="insight-stack">
        <div><strong>Anggaran</strong><span>{formatCompactCurrency(model.monevProgram.realization)} dari {formatCompactCurrency(model.monevProgram.budget)} terealisasi.</span></div>
        <div><strong>PKPT</strong><span>{model.pkpt.status.Belum} penugasan berstatus “Belum”. Prioritaskan pada daftar PKPT.</span></div>
        <div><strong>Data quality</strong><span>{model.meta.formulaErrors ? `${model.meta.formulaErrors} nilai error formula terdeteksi pada workbook.` : 'Tidak ada error formula terdeteksi.'}</span></div>
      </div></section>
    </div>
    <section className="panel table-panel"><div className="panel-head"><div><h3>Monev Program — ringkasan anggaran</h3><span>Source: sheet “Monev Program”</span></div><Pill kind="year">TA {model.meta.year}</Pill></div><div className="budget-strip"><div><span>Pagu</span><strong>{formatCurrency(model.monevProgram.budget)}</strong></div><div><span>Realisasi</span><strong>{formatCurrency(model.monevProgram.realization)}</strong></div><div><span>Persentase</span><strong>{pct(model.monevProgram.progressPct)}</strong></div></div></section>
  </div>
}

function PKPT({ model }) {
  const [filter, setFilter] = useState('Semua')
  const statuses = ['Semua','Sudah','Sedang Berjalan','Belum']
  const rows = model.pkpt.data.filter(r => filter === 'Semua' || r[4] === filter).slice(0, 65)
  return <div className="page">
    <SectionHeader eyebrow="Program kerja pengawasan" title="Rekap Realisasi PKPT" right={<div className="filter-row">{statuses.map(s => <button key={s} className={`filter ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>{s}</button>)}</div>} />
    <div className="metric-grid compact"><div className="mini-kpi panel"><div className="mini-icon"><ClipboardCheck size={17}/></div><div><span>Total</span><strong>{num(model.pkpt.total)}</strong><small>penugasan terbaca</small></div></div><div className="mini-kpi panel"><div className="mini-icon good"><ShieldCheck size={17}/></div><div><span>Selesai</span><strong>{num(model.pkpt.status.Sudah)}</strong><small>{pct(model.pkpt.completion)} dari total</small></div></div><div className="mini-kpi panel"><div className="mini-icon warn"><AlertTriangle size={17}/></div><div><span>Belum</span><strong>{num(model.pkpt.status.Belum)}</strong><small>perlu tindak lanjut</small></div></div><div className="mini-kpi panel"><div className="mini-icon"><TrendingUp size={17}/></div><div><span>Output</span><strong>{num(model.pkpt.outputRealized)}</strong><small>realisasi output tersummary</small></div></div></div>
    <section className="panel table-panel"><div className="panel-head"><div><h3>Daftar penugasan</h3><span>Filter mengikuti kolom “Pemantauan Realisasi”</span></div><Pill>{rows.length} tampil</Pill></div><DataTable columns={['Kegiatan','Status','Irban','Target','Realisasi','Keterangan']} rows={rows.map(r => [r[3], r[4], r[5], `${r[9] ?? '—'} ${r[10] ?? ''}`.trim(), `${r[11] ?? '—'} ${r[12] ?? ''}`.trim(), r[17] || ''])} dense/></section>
  </div>
}

function Budget({ model }) {
  const budget = model.monevProgram.budget || 0
  const realization = model.monevProgram.realization || 0
  const remaining = Math.max(0, budget - realization)
  const series = [{name:'Pagu', value: budget}, {name:'Realisasi', value: realization}, {name:'Sisa', value: remaining}]
  return <div className="page">
    <SectionHeader eyebrow="Resource execution" title="Anggaran & realisasi" right={<Pill kind="year">TA {model.meta.year}</Pill>} />
    <div className="budget-hero panel"><div className="budget-head"><div><span className="eyebrow">Monev Program</span><h3>{formatCurrency(budget)}</h3><p>Total pagu yang terbaca otomatis dari sheet.</p></div><div className="budget-score"><CircleGauge size={20}/><strong>{pct(model.monevProgram.progressPct)}</strong><span>realisasi</span></div></div><div className="big-progress"><span style={{width:`${Math.min(model.monevProgram.progressPct ?? 0, 100)}%`}}/></div><div className="budget-foot"><span>Realisasi <b>{formatCurrency(realization)}</b></span><span>Sisa <b>{formatCurrency(remaining)}</b></span></div></div>
    <div className="two-col">
      <ChartCard title="Komposisi anggaran" subtitle="Pagu vs realisasi vs sisa">
        <ResponsiveContainer width="100%" height={260}><PieChart><Pie data={series} dataKey="value" nameKey="name" innerRadius={68} outerRadius={98} paddingAngle={4}><Cell fill="#7c6cff"/><Cell fill="#62e6c5"/><Cell fill="#39445f"/></Pie><Tooltip formatter={(v) => formatCurrency(v)} contentStyle={{background:'#10162a',border:'1px solid rgba(255,255,255,.1)',borderRadius:14,color:'#fff'}}/></PieChart></ResponsiveContainer>
      </ChartCard>
      <section className="panel insight-panel"><div className="panel-head"><div><h3>Catatan integrasi</h3><span>Dashboard tidak menimpa sumber data.</span></div><Database size={17}/></div><div className="insight-stack"><div><strong>Source</strong><span>Sheet “Monev Program” kolom anggaran & realisasi.</span></div><div><strong>Fallback</strong><span>Bila nilai bersumber dari formula error, kartu terkait akan menampilkan “—” atau masuk ke Data Quality.</span></div><div><strong>Refresh</strong><span>Unggah workbook terbaru untuk mengganti dataset tanpa mengubah kode aplikasi.</span></div></div></section>
    </div>
  </div>
}

function Workpaper({ model, onUpload }) {
  const [sheet, setSheet] = useState(SHEETS[0].key)
  const rows = safeArr(model.rows[sheet])
  const preview = rows.slice(0, 30)
  return <div className="page">
    <SectionHeader eyebrow="Kertas kerja" title="Sumber data operasional" right={<label className="upload-btn"><Upload size={16}/> Upload workbook<input type="file" accept=".xlsx,.xls" onChange={e => e.target.files?.[0] && onUpload(e.target.files[0])}/></label>} />
    <div className="workpaper-layout">
      <aside className="sheet-nav panel">{SHEETS.map(s => <button key={s.key} className={sheet === s.key ? 'active' : ''} onClick={() => setSheet(s.key)}><FileSpreadsheet size={15}/><span>{s.label}</span><small>{(model.rows[s.key] || []).length}</small></button>)}</aside>
      <section className="panel table-panel workarea"><div className="panel-head"><div><h3>{sheet}</h3><span>Preview 30 baris pertama • perubahan di workbook menjadi sumber KPI setelah upload.</span></div><Pill>{rows.length} baris</Pill></div><RawTable rows={preview}/></section>
    </div>
  </div>
}

function Quality({ model }) {
  const checks = SHEETS.map(s => ({ ...s, rows: model.rows[s.key]?.length ?? 0, errors: countErrors(model.rows[s.key] || []) }))
  return <div className="page">
    <SectionHeader eyebrow="Governance data" title="Data Quality & Formula Health" right={<Pill kind={model.meta.formulaErrors ? 'warn' : 'ok'}>{model.meta.formulaErrors ? 'Perlu perhatian' : 'Sehat'}</Pill>} />
    <div className="quality-hero panel"><div className="quality-score"><div className="quality-number">{num(model.meta.formulaErrors)}</div><span>formula error</span></div><div className="quality-copy"><h3>{model.meta.formulaErrors ? 'Ada angka yang belum aman dijadikan KPI.' : 'Workbook siap dipakai sebagai sumber KPI.'}</h3><p>Dashboard memindai seluruh sheet untuk token error umum seperti #REF!, #NAME? dan #DIV/0! supaya angka yang diragukan tidak disamarkan.</p><button className="ghost-btn" onClick={() => window.location.reload()}><RefreshCcw size={15}/> Refresh scan</button></div></div>
    <section className="panel table-panel"><div className="panel-head"><div><h3>Health per sheet</h3><span>Jumlah baris dan error formula yang terdeteksi</span></div></div><DataTable columns={['Sheet','Baris','Error formula','Status']} rows={checks.map(x => [x.label, x.rows, x.errors, x.errors ? 'Perlu cek' : 'OK'])} /></section>
  </div>
}

function countErrors(rows) { let n=0; for (const r of rows || []) for (const v of r || []) if (typeof v === 'string' && /^#(REF!|DIV\/0!|VALUE!|NAME\?|N\/A|NUM!|NULL!)/i.test(v)) n++; return n }

function DataTable({ columns, rows, dense=false }) {
  return <div className={`table-scroll ${dense ? 'dense' : ''}`}><table><thead><tr>{columns.map(c => <th key={c}>{c}</th>)}</tr></thead><tbody>{rows.length ? rows.map((r,i)=><tr key={i}>{r.map((c,j)=><td key={j}>{j===1 && (c==='Sudah'||c==='Sedang Berjalan'||c==='Belum') ? <Pill kind={c==='Sudah'?'ok':c==='Belum'?'warn':'info'}>{c}</Pill> : c == null || c === '' ? '—' : String(c)}</td>)}</tr>) : <tr><td colSpan={columns.length}><EmptyState/></td></tr>}</tbody></table></div>
}
function RawTable({ rows }) {
  const maxCols = Math.min(16, Math.max(1, ...rows.map(r => r.length)))
  const clipped = rows.map(r => Array.from({length:maxCols}, (_,i)=>r?.[i] ?? ''))
  const headers = Array.from({length:maxCols},(_,i)=>String.fromCharCode(65+i))
  return <div className="table-scroll raw"><table><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{clipped.map((r,i)=><tr key={i}>{r.map((c,j)=><td key={j}>{String(c)}</td>)}</tr>)}</tbody></table></div>
}

export default function App() {
  const [model, setModel] = useState(null)
  const [page, setPage] = useState('dashboard')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const fileRef = useRef(null)
  useEffect(() => { loadWorkbook().then(setModel).catch(e => setError(e.message || 'Gagal memuat workbook')).finally(() => setLoading(false)) }, [])
  const go = (p) => { setPage(p); setSidebarOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  const upload = async (file) => { setLoading(true); setError(''); try { setModel(await loadWorkbook(file)) } catch(e) { setError(e.message || 'Workbook tidak bisa dibaca') } finally { setLoading(false) } }
  const content = useMemo(() => {
    if (!model) return null
    if (page === 'performance') return <Performance model={model}/>
    if (page === 'monev') return <Monev model={model}/>
    if (page === 'pkpt') return <PKPT model={model}/>
    if (page === 'budget') return <Budget model={model}/>
    if (page === 'workpaper') return <Workpaper model={model} onUpload={upload}/>
    if (page === 'quality') return <Quality model={model}/>
    return <Dashboard model={model} go={go}/>
  }, [page, model])
  return <div className="app-shell"><AnimatedBackground/>
    <header className="mobile-top"><button onClick={() => setSidebarOpen(v => !v)}><Menu size={20}/></button><div className="brand">KAWAL <span>KINERJA</span></div><div className="mobile-badge">2026</div></header>
    <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
      <div className="brand-block"><div className="brand-mark"><ShieldCheck size={20}/></div><div><strong>KAWAL KINERJA</strong><span>INSPEKTORAT MAHAKAM ULU</span></div></div>
      <div className="side-caption">CONTROL CENTER</div>
      <nav>{nav.map(([id,label,Icon]) => <button key={id} className={page===id?'active':''} onClick={() => go(id)}><Icon size={18}/><span>{label}</span>{page===id && <motion.i layoutId="active-dot"/>}</button>)}</nav>
      <div className="side-bottom"><div className="side-meta"><span>Sumber aktif</span><strong>{model ? 'Workbook 2026' : 'Loading…'}</strong></div><button className="side-upload" onClick={() => fileRef.current?.click()}><Upload size={15}/> Ganti workbook</button><input ref={fileRef} type="file" accept=".xlsx,.xls" style={{display:'none'}} onChange={e=>e.target.files?.[0] && upload(e.target.files[0])}/></div>
    </aside>
    <main className="main"><div className="topbar"><div><span className="top-kicker">DATABASE REALISASI KINERJA</span><strong>{page === 'dashboard' ? 'Executive dashboard' : nav.find(x => x[0] === page)?.[1]}</strong></div><div className="top-actions"><button className="top-search"><Search size={16}/> Cari modul…</button><Pill kind="year">{model?.meta?.year ?? '—'}</Pill></div></div>{loading && <div className="loadingbar"><motion.span initial={{x:'-100%'}} animate={{x:'100%'}} transition={{repeat:Infinity,duration:1.2,ease:'easeInOut'}}/></div>}{error && <div className="error-banner"><AlertTriangle size={16}/><span>{error}</span><button onClick={() => window.location.reload()}><RefreshCcw size={14}/></button></div>}{content}</main>
  </div>
}
