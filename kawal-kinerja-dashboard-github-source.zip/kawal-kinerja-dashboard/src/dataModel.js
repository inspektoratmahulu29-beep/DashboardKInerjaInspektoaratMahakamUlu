import * as XLSX from 'xlsx'

export const WORKBOOK_URL = '/data/database-realisasi-kinerja-2026.xlsx'

export const SHEETS = [
  { key: 'IKU', label: 'IKU' },
  { key: 'Rencana Aksi', label: 'Rencana Aksi' },
  { key: 'Capaian Sasaran Strategis', label: 'Sasaran Strategis' },
  { key: 'Capaian Sasaran Program', label: 'Sasaran Program' },
  { key: 'Capaian Sasaran Kegiatan Utama', label: 'Kegiatan Utama' },
  { key: 'Capaian Sasaran Kegiatan(Penun)', label: 'Kegiatan Penunjang' },
  { key: 'Capaian Sasaran SUBKegiatan(U)', label: 'Subkegiatan Utama' },
  { key: 'Capaian Sasaran SUBKegiatan (P)', label: 'Subkegiatan Penunjang' },
  { key: 'Monev Renaksi IKU', label: 'Monev IKU' },
  { key: 'Monev Program', label: 'Monev Program' },
  { key: 'Monev output Subkegiatan Utama', label: 'Monev Output Utama' },
  { key: 'Monev Subkegiatan Penunjang', label: 'Monev Output Penunjang' },
  { key: 'Rekap realisasi PKPT', label: 'Rekap PKPT' },
  { key: 'Realisasi Fisik & Keu', label: 'Fisik & Keu' }
]

const asText = (v) => v == null ? '' : String(v).trim()
const asNum = (v) => {
  if (typeof v === 'number' && Number.isFinite(v)) return v
  const s = asText(v).replace(/,/g, '')
  if (!s || s.startsWith('#')) return null
  const n = Number(s.replace(/[^0-9.-]/g, ''))
  return Number.isFinite(n) ? n : null
}
const isFormulaError = (v) => /^#(REF!|DIV\/0!|VALUE!|NAME\?|N\/A|NUM!|NULL!)/i.test(asText(v))
const rowHasText = (row, needle) => row.some(v => asText(v).toLowerCase().includes(needle.toLowerCase()))
const lastNonEmptyIndex = (row) => {
  for (let i = row.length - 1; i >= 0; i--) if (asText(row[i])) return i
  return -1
}
const clampPct = (v) => Math.max(0, Math.min(100, v))

function sheetRows(wb, name) {
  const ws = wb.Sheets[name]
  if (!ws) return []
  return XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null })
}

function countFormulaErrors(rows) {
  let count = 0
  for (const row of rows) for (const v of row) if (isFormulaError(v)) count++
  return count
}

function parseRencanaAksi(rows) {
  const data = rows.slice(6).filter(r => asText(r[0]) || asText(r[3]) || asText(r[6]))
  const indicators = data.filter(r => asText(r[3]) && !asText(r[3]).startsWith('Realisasi'))
  const quarterly = { tw1: 0, tw2: 0, tw3: 0, tw4: 0 }
  for (const r of indicators) {
    for (let i = 0; i < 4; i++) if (asText(r[7 + i])) quarterly[`tw${i + 1}`]++
  }
  return { count: indicators.length, data, quarterly }
}

function parseIku(rows) {
  const data = rows.slice(7).filter(r => asText(r[1]) || asText(r[2]) || asText(r[3]))
  return { count: data.length, data }
}

function parseCapaian(rows, indicatorIndex) {
  const data = rows.slice(3).filter(r => asText(r[indicatorIndex]))
  const values = data.map(r => ({
    label: asText(r[indicatorIndex]),
    target: asNum(r[indicatorIndex + 2]),
    realization: asNum(r[indicatorIndex + 3]),
    achievement: asNum(r[indicatorIndex + 4]),
    budget: asNum(r[indicatorIndex + 6]),
    spending: asNum(r[indicatorIndex + 7]),
    spendingPct: asNum(r[indicatorIndex + 8])
  }))
  return { count: values.length, values, data }
}

function parseMonevProgram(rows) {
  const data = rows.slice(8)
  const budget = data.reduce((a, r) => a + (asNum(r[19]) ?? 0), 0)
  const realization = data.reduce((a, r) => a + (asNum(r[20]) ?? 0), 0)
  const progressPct = budget ? realization / budget * 100 : null
  const tw = [1,2,3,4].map((n, i) => data.reduce((a, r) => {
    const v = asText(r[16 + i])
    const m = v.match(/(\d+(?:\.\d+)?)\s*(?:LHP|LHE|Lap|lap|laporan|Laporan)/)
    return a + (m ? Number(m[1]) : 0)
  }, 0))
  const programRows = data.filter(r => asNum(r[19]) != null || asNum(r[20]) != null)
  return { budget, realization, progressPct, programRows, quarterlyOutputs: tw }
}

function parseMonevOutput(rows, startRow, fallbackIndex = 7) {
  const data = rows.slice(startRow).filter(r => asText(r[7]) || asText(r[fallbackIndex]))
  const activities = data.map((r, idx) => ({
    no: idx + 1,
    program: asText(r[2]),
    kegiatan: asText(r[4]),
    subkegiatan: asText(r[6]),
    activity: asText(r[7]) || asText(r[fallbackIndex]),
    pengampu: asText(r[8]),
    pptk: asText(r[9]),
    output: asNum(r[11]),
    kendala: asText(r[12]),
    tindakLanjut: asText(r[13])
  }))
  return { count: activities.length, activities }
}

function parsePKPT(rows) {
  const cutoff = rows.findIndex((r, i) => i > 80 && rowHasText(r, 'REALISASI OUTPUT PENUGASAN'))
  const end = cutoff > 0 ? cutoff : Math.min(rows.length, 91)
  const data = rows.slice(6, end).filter(r => asText(r[3]))
  const status = { Sudah: 0, 'Sedang Berjalan': 0, Belum: 0, Lainnya: 0 }
  let target = 0, realized = 0
  const byIrban = {}
  for (const r of data) {
    const s = asText(r[4])
    if (s === 'Sudah' || s === 'Sedang Berjalan' || s === 'Belum') status[s]++
    else status.Lainnya++
    const t = asNum(r[9]); const rr = asNum(r[11])
    target += t ?? 0
    realized += rr ?? 0
    const irban = asText(r[5]) || 'Belum terisi'
    byIrban[irban] ??= { total: 0, sudah: 0, berjalan: 0, belum: 0 }
    byIrban[irban].total++
    if (s === 'Sudah') byIrban[irban].sudah++
    if (s === 'Sedang Berjalan') byIrban[irban].berjalan++
    if (s === 'Belum') byIrban[irban].belum++
  }
  const summaryStart = rows.findIndex((r, i) => i > 80 && rowHasText(r, 'REALISASI OUTPUT PENUGASAN'))
  const summary = []
  if (summaryStart >= 0) {
    for (const r of rows.slice(summaryStart + 2)) {
      if (!asText(r[3])) continue
      const n = asNum(r[4])
      if (n != null) summary.push({ label: asText(r[3]), value: n })
    }
  }
  return { data, total: data.length, status, target, realized, byIrban, completion: data.length ? status.Sudah / data.length * 100 : null, progress: data.length ? (status.Sudah + status['Sedang Berjalan']) / data.length * 100 : null, outputSummary: summary, outputRealized: summary.reduce((a, x) => a + x.value, 0) }
}

function parseFisikKeu(rows) {
  const errors = countFormulaErrors(rows)
  const data = rows.slice(9).filter(r => asText(r[1]) || asNum(r[2]) != null)
  const summaryRows = data.filter(r => /^\d+$/.test(asText(r[0])) && asText(r[1]).toLowerCase().includes('program'))
  const validSummary = summaryRows.map(r => ({
    label: asText(r[1]), budget: asNum(r[2]), physical: asNum(r[4]), physicalWeighted: asNum(r[5]), financial: asNum(r[7]), financialWeighted: asNum(r[8]), remaining: asNum(r[9])
  }))
  const leaves = data.filter(r => !asText(r[0]) && !asText(r[1]) && asNum(r[2]) != null)
  const validWeighted = leaves.filter(r => asNum(r[5]) != null && asNum(r[8]) != null)
  const sumBudget = leaves.reduce((a, r) => a + (asNum(r[2]) ?? 0), 0)
  const sumRealization = leaves.reduce((a, r) => a + (asNum(r[6]) ?? 0), 0)
  const weightedPhysical = validWeighted.reduce((a, r) => a + (asNum(r[5]) ?? 0), 0)
  const weightedFinancial = validWeighted.reduce((a, r) => a + (asNum(r[8]) ?? 0), 0)
  return { errors, data, validSummary, sumBudget, sumRealization, weightedPhysical, weightedFinancial }
}

export function buildModel(wb) {
  const rows = Object.fromEntries(SHEETS.map(s => [s.key, sheetRows(wb, s.key)]))
  const iku = parseIku(rows.IKU)
  const rencana = parseRencanaAksi(rows['Rencana Aksi'])
  const strategic = parseCapaian(rows['Capaian Sasaran Strategis'], 2)
  const program = parseCapaian(rows['Capaian Sasaran Program'], 3)
  const kegiatan = parseCapaian(rows['Capaian Sasaran Kegiatan Utama'], 5)
  const penunjangKegiatan = parseCapaian(rows['Capaian Sasaran Kegiatan(Penun)'], 5)
  const subU = parseCapaian(rows['Capaian Sasaran SUBKegiatan(U)'], 5)
  const subP = parseCapaian(rows['Capaian Sasaran SUBKegiatan (P)'], 6)
  const monevIku = { ...parseMonevOutput(rows['Monev Renaksi IKU'], 8, 3), count: rows['Monev Renaksi IKU'].slice(8).filter(r => asText(r[3])).length }
  const monevProgram = parseMonevProgram(rows['Monev Program'])
  const outputUtama = parseMonevOutput(rows['Monev output Subkegiatan Utama'], 6)
  const outputPenunjang = parseMonevOutput(rows['Monev Subkegiatan Penunjang'], 6)
  const pkpt = parsePKPT(rows['Rekap realisasi PKPT'])
  const fisikKeu = parseFisikKeu(rows['Realisasi Fisik & Keu'])
  const errors = Object.values(rows).reduce((a, r) => a + countFormulaErrors(r), 0)
  const allSheetRows = Object.values(rows).reduce((a, r) => a + r.length, 0)
  const yearText = Object.values(rows).flatMap(r => r.slice(0, 6)).flat().map(asText).find(v => /20\d{2}/.test(v)) || '2026'
  const detectedYear = Number((yearText.match(/20\d{2}/) || ['2026'])[0])

  return {
    rows, iku, rencana, strategic, program, kegiatan, penunjangKegiatan, subU, subP,
    monevIku, monevProgram, outputUtama, outputPenunjang, pkpt, fisikKeu,
    meta: {
      year: detectedYear,
      sheetCount: SHEETS.length,
      rowCount: allSheetRows,
      formulaErrors: errors,
      totalBudget: monevProgram.budget,
      totalRealization: monevProgram.realization,
      budgetPct: monevProgram.progressPct,
      pkptProgress: pkpt.progress,
      physicalPct: fisikKeu.validSummary.length ? Math.max(...fisikKeu.validSummary.map(x => x.physicalWeighted ?? 0)) : null,
      financialPct: fisikKeu.validSummary.length ? Math.max(...fisikKeu.validSummary.map(x => x.financialWeighted ?? 0)) : null,
    }
  }
}

export async function loadWorkbook(fileOrUrl = WORKBOOK_URL) {
  const ab = fileOrUrl instanceof File ? await fileOrUrl.arrayBuffer() : await (await fetch(fileOrUrl)).arrayBuffer()
  const wb = XLSX.read(ab, { type: 'array', cellFormula: true, cellNF: true, cellDates: true })
  return buildModel(wb)
}

export function formatCurrency(n) {
  if (n == null || !Number.isFinite(n)) return '—'
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n)
}

export function formatCompactCurrency(n) {
  if (n == null || !Number.isFinite(n)) return '—'
  const abs = Math.abs(n)
  if (abs >= 1e12) return `Rp ${(n / 1e12).toFixed(2)} T`
  if (abs >= 1e9) return `Rp ${(n / 1e9).toFixed(2)} M`
  if (abs >= 1e6) return `Rp ${(n / 1e6).toFixed(1)} jt`
  if (abs >= 1e3) return `Rp ${(n / 1e3).toFixed(0)} rb`
  return formatCurrency(n)
}

export { asNum, asText, clampPct }
