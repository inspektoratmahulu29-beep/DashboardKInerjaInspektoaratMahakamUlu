# Kawal Kinerja — Database Realisasi Kinerja Inspektorat Mahakam Ulu

Dashboard web untuk membaca workbook **Database Realisasi Kinerja Inspektorat Kabupaten Mahakam Ulu** secara langsung di browser.

## Fitur utama

- UI dark glassmorphism dengan gradient, glow, animated orbs, radar ring, progress bar, dan micro-interactions.
- KPI terhubung ke sheet workbook melalui parser `xlsx` di sisi browser.
- Modul Dashboard, Kinerja, Monev, PKPT, Anggaran, Kertas Kerja, dan Data Quality.
- Tombol **Upload workbook** untuk mengganti sumber data tanpa mengubah kode aplikasi.
- Data Quality memindai formula error umum seperti `#REF!`, `#NAME?`, `#DIV/0!` agar angka bermasalah tidak disamarkan.
- Workbook contoh tersimpan di `public/data/database-realisasi-kinerja-2026.xlsx`.

## Jalankan lokal

```bash
npm install
npm run dev
```

Buka URL yang diberikan Vite.

## Build production

```bash
npm run build
```

Output ada di `dist/`.

## Deploy Cloudflare Pages via GitHub

Cloudflare Pages mendukung koneksi langsung ke repository GitHub dan akan otomatis membangun ulang setiap push. Untuk React + Vite gunakan:

- Production branch: `main`
- Build command: `npm run build`
- Build output directory: `dist`

Langkah umum:

```bash
git init
git add .
git commit -m "Initial dashboard kinerja"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```

Kemudian di Cloudflare: **Workers & Pages → Create application → Pages → Import existing Git repository**, pilih repository tersebut, lalu isi pengaturan build di atas.

## Struktur

```text
.
├─ public/
│  ├─ _redirects
│  └─ data/
│     └─ database-realisasi-kinerja-2026.xlsx
├─ src/
│  ├─ App.jsx
│  ├─ dataModel.js
│  ├─ main.jsx
│  └─ styles.css
├─ index.html
├─ package.json
└─ vite.config.js
```

## Catatan integrasi data

Dashboard sengaja memakai pendekatan **client-side parsing**. Artinya workbook tidak perlu diupload ke server aplikasi; browser membaca XLSX, mengubah sheet menjadi array, lalu menghitung KPI dari data yang sedang dipakai. Ini cocok untuk Cloudflare Pages static hosting dan juga memudahkan pengguna mengganti workbook 2026/2027/2028 tanpa mengubah source.

Beberapa formula pada workbook contoh memang sudah berisi token error. Aplikasi menandainya di modul Data Quality dan tidak mencoba mengarang nilai pengganti.

## Referensi Cloudflare

- GitHub integration: https://developers.cloudflare.com/pages/configuration/git-integration/github-integration/
- Build configuration: https://developers.cloudflare.com/pages/configuration/build-configuration/
- React on Pages: https://developers.cloudflare.com/pages/framework-guides/deploy-a-react-site/
